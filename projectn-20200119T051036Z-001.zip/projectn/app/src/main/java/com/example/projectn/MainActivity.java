package com.example.projectn;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;



public class MainActivity extends AppCompatActivity {

    public EditText emailid,pwd,cnfpwd;
    Button btnsignup;
    TextView tvsignin;
    FirebaseAuth mFirebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(MainActivity.this,"Welcome!",Toast.LENGTH_LONG);

        mFirebaseAuth = FirebaseAuth.getInstance();
        emailid=findViewById(R.id.edittext_email);
        pwd=findViewById(R.id.edittext_password);
        cnfpwd=findViewById(R.id.edittext_cnfpassword);
        btnsignup=findViewById(R.id.button_register);
        tvsignin=findViewById(R.id.textview_login);
        btnsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String email=emailid.getText().toString();
                String password=pwd.getText().toString();
                String cnfpassword=cnfpwd.getText().toString();
                if(email.isEmpty()) {
                    emailid.setError("Please enter email id");
                    emailid.requestFocus();
                }
                else if(password.isEmpty())
                {
                    pwd.setError("Please enter the password");
                    pwd.requestFocus();
                }
                else if(cnfpassword.isEmpty())
                {
                    cnfpwd.setError("Please re-enter the password");
                    cnfpwd.requestFocus();
                }
                else if(!password.equals(cnfpassword))
                {
                    Toast.makeText(MainActivity.this,"Passwords did not match",Toast.LENGTH_LONG).show();
                }
                //else if(password.isEmpty() && email.isEmpty())
               // {
                   // Toast.makeText(MainActivity.this,"Fields are empty",Toast.LENGTH_SHORT).show();
               // }
                else if(!email.isEmpty() && !password.isEmpty()){
                    mFirebaseAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){
                                startActivity(new Intent(MainActivity.this,HomeActivity.class));

                            }
                            else{
                                Toast.makeText(MainActivity.this,"Signup Unsuccessful",Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                }
                else
                {
                    Toast.makeText(MainActivity.this,"Error occured!",Toast.LENGTH_SHORT).show();
                }
            }
        });
        tvsignin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v)
            {
                Intent i=new Intent(MainActivity.this,LoginActivity.class);
                startActivity(i);
            }
        });
    }
}
